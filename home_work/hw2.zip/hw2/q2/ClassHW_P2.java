public class ClassHW_P2 {
    public static void main(String[] args){
        
    }
    
}
