'''
Author      Jonathan Hogan
Class       Dr.Das - CMPS 4143 Contemporary Programming Languages
Due         10/27/21                                                   
 
Program for Question 1: Write a Python program to draw a 
three-stage rocket (25 points)
'''

print('\t    *\n\t   * *\n\t  *   *\n\t *     *\n\t*********')
print('\t||  ^  ||\n\t||  X  ||\n\t||  v  ||\n\t=========')
print('\t||  ^  ||\n\t||< X >||\n\t||  v  ||\n\t=========')
print('\t||  ^  ||\n\t||  X  ||\n\t||  v  ||\n\t=========')
print('\tWWWWWWWWW\n\t WWWWWWW\n\t  WWWWW\n\t   WWW\n\t    W')